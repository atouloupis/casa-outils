jQuery(document).ready(function($) {
	jQuery('.image-in-widget-plugin').zoom();
});