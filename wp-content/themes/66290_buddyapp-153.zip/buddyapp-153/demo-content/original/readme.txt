Our theme has the option to install the demo pages from WordPress admin. Please go to theme dashboard and go to Demo content to use the 1 Click install.

To manually import the .xml files please follow the instructions bellow: 



To manually import our Demo content you should install WordPress Importer plugin

http://wordpress.org/extend/plugins/wordpress-importer/

1 - Download it and upload on your server (wp-content/plugins) or install it from Wordpress Admin -> Plugins

2 - Go to tools - Import

3 - Choose "Wordpress"

4 - Upload one of the xml files, depending on the demo you want (choose to import images if you want)


5 - Done!
