
/* <![CDATA[ */

    $(document).ready(function() {
      
      $('#fullpage').fullpage({
          /*sectionsColor: ['#1bbc9b', '#4BBFC3', '#7BAABE', 'whitesmoke', '#ccddff'],*/
          anchors: ['home', 'feature-01', 'feature-02', 'feature-03', 'feature-04' , 'feature-05' , 'feature-06' , 'feature-07' , 'feature-08' , 'feature-09' , 'feature-10' , 'feature-11', 'feature-12'],
          menu: '#menu',
          scrollingSpeed: 1000,
          responsiveWidth: 754,
          responsiveHeight: 650,
        
          //events
          onLeave: function(index, nextIndex, direction) {
            $(".navbar-collapse").removeClass("in");
            $('#header').removeClass("show");
            
            if(!$("#fullpage").hasClass("fp-responsive")){
              $(".navbar").fadeOut(100);
            }
          },
          afterLoad: function(anchorLink, index){
            if(!$("#fullpage").hasClass("fp-responsive")){
              $(".navbar").fadeIn(300);
            }
            
            $("body").attr("class","").addClass("page-" + (index - 1));
          }
      });
      
      
      $('#navbar').on('show.bs.collapse', function () {
        $("#header").addClass("show");
      });
      
      
      $('#navbar').on('hide.bs.collapse', function () {
        $("#header").removeClass("show");
      });
      
    });

				
/* ]]> */

		
